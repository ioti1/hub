# Base de Apoio do HUB

Esta pasta guarda os arquivos exibidos no menu **Central de Apoio** do HUB.

Organização sugerida:

- `Documentos` — PDFs, Word e apresentações;
- `Manuais` — procedimentos e guias operacionais;
- `Tabelas` — planilhas, dicionários e catálogos de códigos;
- `De-Para` — mapeamentos e comparações.

Depois de adicionar ou remover arquivos, entre no **Admin do HUB → Central de Apoio** e use **Indexar pasta de apoio**. A aplicação transforma a estrutura desta pasta em um catálogo pesquisável. Revise o resultado e clique em **Publicar para todos** para atualizar o JSON e o arquivo JS compartilhado.

O navegador não permite que um HTML local examine pastas silenciosamente. Por isso, somente o administrador autoriza esta pasta uma vez; os demais usuários consultam o catálogo sem nenhuma seleção.
