# HUB Cadastro v15.1

## Novidades da v15.1

- **Previdência em pauta** fica em uma tarja fina entre a imagem e os painéis, usando os três temas existentes. O quadro lateral de notícias saiu; aplicações e calendário mantêm recuos e espaçamentos consistentes, sem um bloco vazio no lugar das notícias.
- A faixa mostra **até seis notícias disponíveis**, em ordem de data e sem repetir endereços, usando as fontes, filtros e RSS já configurados. Agência Brasil e InfoMoney permanecem no fluxo atual.
- Movimento lento, com pausa por mouse/teclado e botão para pausar. Essa escolha fica somente no navegador, sem alterar o JSON. A opção **Reduzir movimento** do dispositivo elimina a animação.
- Os títulos abrem a fonte em outra aba. O botão de lista mostra todas as manchetes por inteiro, data/fonte, situação da consulta e links das fontes; o botão de atualização força a consulta.
- Sem internet ou com bloqueio corporativo/CORS, usa o cache disponível e informa a condição. Não são inventadas notícias para completar seis itens.
- Aplicações, favoritos, três modos de visualização, documentos, links, agentes, temas, agenda completa, autoria geral e publicação protegida foram preservados. A v14 continua separada para eventual retorno.

**Para instalar esta revisão, substitua somente o HTML e mantenha o JSON/JS atual do trabalho, seus documentos e as pastas das aplicações.** O par de configuração do pacote é uma cópia dos oficiais enviados; não o coloque por cima de uma versão mais recente. Ao abrir o HTML em outra pasta, autorize a pasta correspondente em **Pasta de publicação**. Não há servidor nem bibliotecas novas.

O pacote mantém os PDFs existentes na pasta de apoio. Confira os documentos e a visibilidade do repositório antes do Git; nada foi publicado automaticamente.

## Como abrir e levar para o trabalho

Abra **HUB Cadastro v15.1.html**. Os estilos e scripts de interface já estão dentro do HTML: não é necessário transportar os antigos arquivos `hub-v13-*.css` ou `hub-v13-*.js`.

Mantenha junto do HTML:

- `assets` — imagens locais do cabeçalho e logos;
- `hub-cadastro-config.json` e `hub-cadastro-config.js` — sua configuração compartilhada;
- `Base de Apoio` — seus documentos, se os caminhos configurados apontarem para essa pasta.

**IMPORTANTE: este pacote usa os arquivos oficiais enviados em 06/10, não uma configuração de exemplo.** As sete aplicações, seus caminhos, links e documentos foram preservados. JSON e JS foram sincronizados com a descrição do evento que estava preenchida no JS e com InfoMoney habilitado. Os arquivos originais enviados não foram alterados. Antes de instalar, guarde uma cópia do HTML/JSON/JS atuais e exporte qualquer rascunho ainda não publicado.

Nesta revisão não é necessário substituir os arquivos de configuração: atualize o HTML e preserve seu JSON/JS corrente. Se houver atalhos apontando para o nome antigo do HTML, você pode manter aquele nome ao substituí-lo. Se algum dia precisar instalar um par de configuração, JSON e JS devem ser substituídos juntos e somente após revisar se há publicações mais recentes. Não há campos obrigatórios novos.

Se os apontamentos usam caminhos relativos, mantenha a mesma posição da pasta do HUB em relação aos arquivos. Prefira colocar o novo HTML na pasta atual do HUB junto de `assets`, sem mover seu JSON/JS ou documentos. O fluxo de publicação offline e a senha do Admin são os mesmos. Não há servidor, GIF, vídeo nem bibliotecas novas.

## O que mudou

### Atalhos na barra superior

- **Documentos rápidos** e **Links úteis** têm ícone e nome. Ao passar o mouse ou focar com o teclado, uma prévia mostra até cinco atalhos clicáveis. O clique no botão abre a página completa; seta para baixo acessa os itens e Esc fecha a prévia. Em dispositivos de toque, clique para abrir a página.
- A prévia de documentos começa pela ordem do Admin. Conforme os arquivos são abertos neste navegador, os mais consultados localmente têm prioridade. Essa contagem não é uma estatística compartilhada de todo o setor.
- A página **Links úteis** reúne todos os links publicados, tem pesquisa, ordem alfabética e favoritos primeiro. Estrelas, ordenação e contagens de acesso ficam apenas no navegador, sem acrescentar campos ao JSON compartilhado.
- Os ícones de sino e grade foram retirados dessa barra. Notícias permanecem no quadro lateral; Central de Apoio está no rodapé da prévia de Documentos, e Ajuda/Agentes também podem ser acessados pela busca geral (Ctrl+K).
- O botão de tema indica a **próxima opção**: nuvem para mudar de Manhã para Tarde, lua para mudar de Tarde para Noite e sol para retornar a Manhã. No tema Noite, os agentes ficam dourados sem alterar seu estilo salvo, as estrelas não selecionadas têm fundo cinza-claro e os botões usam hover claro com texto preto, sem azul.
- Links úteis permanece na barra superior e na página completa, sem quadro duplicado na lateral. Em telas de computador, o catálogo e a coluna de Próximos eventos + Previdência em pauta têm a mesma altura total; em telas pequenas seguem empilhados.

### Ajustes de paleta e navegação

- Tarde recupera o azul original do HUB, sem a tonalidade verde adicionada na revisão anterior. Noite usa quadros grafite, textos claros e ícones/detalhes dourados, inclusive nos painéis laterais.
- O calendário fica alinhado à linha do primeiro evento, com datas menores e espaçamento compacto. Os títulos de Próximos eventos e Previdência em pauta ficam centralizados, com respiro antes do conteúdo. Horários aparecem como “Horário: 11:21 até 13:21”. A autoria aparece pequena e em itálico: “Criado por: nome · 06/10 às 10:21”, sem parênteses. Quando não houver registro, essa linha não é exibida.
- No Admin, abra **Personalizar títulos** abaixo da lista de seções para renomear os menus e seus respectivos quadros. Deixe um campo em branco para voltar ao padrão e use **Publicar para todos** para compartilhar. Os nomes são opcionais: apenas quando personalizados é salvo o pequeno objeto `portal.labels`; JSONs antigos continuam funcionando, sem migrar ou substituir os apontamentos.
- Documentos rápidos usa um ícone de documento no cabeçalho. O retorno **Voltar ao início** fica acima do título, com uma seta, separado da pesquisa.

- **Aplicações do Cadastro:** cards, lista e nova opção compacta. Apenas o seletor de visualização permanece no catálogo; favoritos, Abrir e Detalhes continuam funcionando. A busca geral fica centralizada no cabeçalho.
- **Próximos eventos:** coluna auxiliar, acima de Previdência em pauta. Lista dos próximos três à esquerda e calendário marcado à direita. Clique nas datas para consultar os títulos e navegue entre os meses pelas setas. Eventos encerrados/cancelados não entram na lista futura.
- Novos eventos começam com horário de **08:00 até 17:00**, editável no Admin. No topo de Calendário e eventos, **Exibir quem criou os eventos para todos** controla a agenda inteira, independentemente das opções individuais antigas. Vem marcado; desmarque e publique para ocultar a identificação em todos os eventos. O registro interno é preservado. Apenas a opção desmarcada acrescenta `showAuthorship:false` à configuração do calendário; arquivos antigos continuam compatíveis.
- Quando houver mais de três eventos futuros, **Ver mais** aparece no rodapé do quadro e abre uma página com toda a agenda futura, ordenada por data e horário. Eventos cancelados ou encerrados são excluídos da lista; a opção geral de autoria vale também nessa página. Use **Voltar ao início** para retornar.

### Publicação e notebooks

- **Revisão da pasta de publicação:** a autorização agora é vinculada ao endereço de cada HTML. A antiga autorização global não é reutilizada. Na primeira publicação após esta revisão, escolha a pasta que contém exatamente o HTML aberto. No Admin, **Pasta de publicação** permite corrigir a escolha sem descartar o rascunho. Bloqueios agora indicam arquivo, etapa e versões comparadas, quando disponíveis.
- Para instalar esta revisão, basta substituir o HTML, mantendo seu JSON e JS atuais se já estiverem sincronizados. Antes de fechar uma sessão com alterações não publicadas, exporte o rascunho. Não substitua configurações que tenham recebido novas publicações pelo par antigo do pacote.
- A base carregada é um snapshot independente do formulário. Valores equivalentes (como `6` e `"6"`) e padrões opcionais não geram divergências falsas entre JSON e JS.
- Se outra pessoa publicou antes de você, alterações em campos distintos e eventos novos com IDs diferentes são combinados. Disputas pelo mesmo campo, remoção versus edição ou alterações durante a gravação continuam bloqueadas para preservar os dados. O rascunho não é descartado; exporte-o antes de reabrir nesses casos.
- Breakpoints de notebook mantêm os títulos à esquerda, reservam espaço para eventos/calendário e usam duas ou três colunas de aplicações conforme a largura. Em telas estreitas, os painéis são empilhados.
- Validação: testes automatizados de publicação, dados oficiais e metadados. A inspeção visual da janela não foi autorizada nesta rodada; valide a apresentação em seu notebook antes de subir ao Git.
- **Documentos rápidos:** botão de pasta no cabeçalho e item no menu abrem uma página própria do HUB com os documentos cadastrados, busca e retorno às aplicações. Os arquivos continuam abrindo em uma nova aba.
- **Agentes:** canto inferior esquerdo, expandindo ao passar o mouse ou focar com o teclado. Estilos claro/escuro respeitam o Admin. A edição de cada agente agora pode ser recolhida, sem descartar campos.
- **Aparência:** botão alterna Manhã (claro), Tarde (azul petróleo/verde) e Noite (preto suave/dourado/branco).
- **Posição dos painéis:** botão ao lado do tema alterna esquerda/direita. Em telas estreitas, os painéis ficam abaixo das aplicações para manter a leitura.
- O logo abre o site da Petros em nova aba.

Tema e posição são salvos **neste navegador/perfil**, não no JSON compartilhado. Limpar os dados do navegador ou usar outro perfil redefine essas preferências. Recarregue com **Ctrl+F5** depois de atualizar; publique ou exporte rascunhos antes de fechar uma sessão de edição.

## Verificação

Código validado com testes de sintaxe, navegação, temas, preferências locais, calendário, favoritos e publicação compartilhada em ambiente simulado. Os arquivos JSON/JS deste pacote são idênticos aos anteriores. As notícias continuam dependentes de internet e das permissões das fontes/rede corporativa. A validação visual no seu navegador e monitor deve ser feita antes da publicação no Git.
